﻿using Exercise13;

PhoneBook MyPhoneBook = new PhoneBook();

foreach (Contact contact in MyPhoneBook)
{
    contact.Call();
}