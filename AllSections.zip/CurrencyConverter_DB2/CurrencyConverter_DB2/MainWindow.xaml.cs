﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CurrencyConverter_DB2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlConnection = new SqlConnection();
        SqlCommand sqlCommand = new SqlCommand();
        SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();

        private int CurrencyId = 0;
        private double FromAmount = 0;
        private double ToAmount = 0;

        public MainWindow()
        {
            InitializeComponent();
            BindCurrency();
            GetData();
        }

        private void ConnectToDatabase()
        {
            string connectionString = ConfigurationManager
                .ConnectionStrings["CurrencyConverter_DB2.Properties.Settings.CurrencyConverterConnectionString"]
                .ConnectionString;
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
        }

        private void BindCurrency()
        {
            ConnectToDatabase();

            DataTable dtCurrency = new DataTable();
            sqlCommand = new SqlCommand(@"SELECT Id, CurrencyName FROM Currency_Master", sqlConnection);
            sqlCommand.CommandType = CommandType.Text;

            sqlDataAdapter = new SqlDataAdapter(sqlCommand);

            sqlDataAdapter.Fill(dtCurrency);

            DataRow newRow = dtCurrency.NewRow();
            newRow["Id"] = 0;
            newRow["CurrencyName"] = "--SELECT--";

            dtCurrency.Rows.InsertAt(newRow, 0);

            if (dtCurrency != null && dtCurrency.Rows.Count > 0)
            {
                cmbFromCurrency.ItemsSource = dtCurrency.DefaultView;
                cmbToCurrency.ItemsSource = dtCurrency.DefaultView;
            }

            sqlConnection.Close();

            //FromCurrency
            cmbFromCurrency.DisplayMemberPath = "CurrencyName";
            cmbFromCurrency.SelectedValuePath = "Id";
            cmbFromCurrency.SelectedIndex = 0;

            //ToCurrency
            cmbToCurrency.DisplayMemberPath = "CurrencyName";
            cmbToCurrency.SelectedValuePath = "Id";
            cmbToCurrency.SelectedIndex = 0;

        }

        private void Convert_Click(object sender, RoutedEventArgs e)
        {
            double convertedValue;

            if (string.IsNullOrEmpty(txtCurrency.Text))
            {
                MessageBox.Show("Please Enter Currency", "Information",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                txtCurrency.Focus();

                return;
            }
            else if (cmbFromCurrency.SelectedValue == null || cmbFromCurrency.SelectedIndex == 0)
            {
                MessageBox.Show(
                    "Please Enter Currency From",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
                cmbFromCurrency.Focus();
                return;
            }
            else if (cmbToCurrency.SelectedValue == null || cmbToCurrency.SelectedIndex == 0)
            {
                MessageBox.Show(
                    "Please Enter Currency To",
                    "Information",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
                cmbToCurrency.Focus();
                return;
            }


            if (cmbFromCurrency.Text == cmbToCurrency.Text) // equal, just display value
            {
                convertedValue = double.Parse(cmbFromCurrency.Text);
                lblCurrency.Content = cmbToCurrency.Text + " " + convertedValue.ToString("N3"); // 3 zeroes after dot
            }
            else
            {
                // perform operation
                convertedValue =
                    (double.Parse(cmbFromCurrency.SelectedValue.ToString()) *
                    double.Parse(txtCurrency.Text)) /
                    double.Parse(cmbToCurrency.SelectedValue.ToString());

                lblCurrency.Content = cmbToCurrency.Text + " " + convertedValue.ToString("N3");
            }

        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }


        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            txtCurrency.Text = string.Empty;

            if (cmbFromCurrency.Items.Count > 0)
                cmbFromCurrency.SelectedIndex = 0;

            if (cmbToCurrency.Items.Count > 0)
                cmbToCurrency.SelectedIndex = 0;

            lblCurrency.Content = "";
            txtCurrency.Focus();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtAmount.Text))
                {
                    MessageBox.Show("Please enter amount", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtAmount.Focus();
                    return;
                }
                else if (string.IsNullOrEmpty(txtCurrencyName.Text))
                {
                    MessageBox.Show("Please enter currency name", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtCurrencyName.Focus();
                    return;
                }
                else
                {
                    if (CurrencyId > 0)
                    {
                        if (MessageBox.Show("Are you sure you want to update?",
                            "Information", MessageBoxButton.YesNo,
                            MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            ConnectToDatabase();

                            DataTable dataTable = new DataTable();

                            sqlCommand = new SqlCommand(@"
                                    UPDATE Currency_Master
                                    SET 
                                        Amount = @Amount,
                                        CurrencyName = @CurrencyName
                                    WHERE Id = @Id", sqlConnection);

                            sqlCommand.CommandType = CommandType.Text;
                            sqlCommand.Parameters.AddWithValue("@Id", CurrencyId);
                            sqlCommand.Parameters.AddWithValue("@Amount", txtAmount.Text);
                            sqlCommand.Parameters.AddWithValue("@CurrencyName", txtCurrencyName.Text);
                            sqlCommand.ExecuteNonQuery();

                            sqlConnection.Close();

                            MessageBox.Show("Data updated successfully", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    else
                    {
                        if (MessageBox.Show("Are you sure you want to save?", "Information",
                            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            ConnectToDatabase();

                            DataTable dataTable = new DataTable();

                            sqlCommand = new SqlCommand(@"
                                    INSERT INTO Currency_Master (
                                        Amount,
                                        CurrencyName
                                    )
                                    VALUES (
                                        @Amount,
                                        @CurrencyName
                                    )", sqlConnection);

                            sqlCommand.CommandType = CommandType.Text;
                            sqlCommand.Parameters.AddWithValue("@Amount", txtAmount.Text);
                            sqlCommand.Parameters.AddWithValue("@CurrencyName", txtCurrencyName.Text);
                            sqlCommand.ExecuteNonQuery();

                            sqlConnection.Close();

                            MessageBox.Show("Data updated successfully", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    ClearMaster();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        // Clear all input
        private void ClearMaster()
        {
            try
            {
                txtAmount.Text = string.Empty;
                txtCurrencyName.Text = string.Empty;
                btnSave.Content = "Save";
                GetData();
                CurrencyId = 0;
                BindCurrency();
                txtAmount.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Bind Data in DataGrid View
        private void GetData()
        {
            ConnectToDatabase();

            DataTable dataTable = new DataTable();

            sqlCommand = new SqlCommand(@"SELECT * FROM Currency_Master", sqlConnection);
            sqlCommand.CommandType = CommandType.Text;

            sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dataTable);

            if (dataTable != null && dataTable.Rows.Count > 0)
                dgvCurrency.ItemsSource = dataTable.DefaultView;
            else
                dgvCurrency.ItemsSource = null;

            sqlConnection.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClearMaster();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgvCurrency_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            try
            {
                DataGrid grd = (DataGrid)sender;
                DataRowView row_selected = grd.CurrentItem as DataRowView;

                if (row_selected != null)
                {
                    if(dgvCurrency.Items.Count > 0)
                    {
                        if(grd.SelectedCells.Count > 0)
                        {
                            CurrencyId = Int32.Parse(row_selected["Id"].ToString());

                            if (grd.SelectedCells[0].Column.DisplayIndex == 0) // Its edit cell
                            {
                                txtAmount.Text = row_selected["Amount"].ToString();
                                txtCurrencyName.Text = row_selected["CurrencyName"].ToString();
                                btnSave.Content = "Update";
                            }
                            else if (grd.SelectedCells[0].Column.DisplayIndex == 1) // Its delete cell
                            {
                                if(MessageBox.Show("Are you sure you want to delete?", "Information", MessageBoxButton.YesNo,
                                    MessageBoxImage.Question) == MessageBoxResult.Yes)
                                {
                                    ConnectToDatabase();

                                    DataTable dataTable = new DataTable();

                                    sqlCommand = new SqlCommand(@"DELETE FROM Currency_Master WHERE Id = @Id", sqlConnection);
                                    sqlCommand.CommandType = CommandType.Text;

                                    sqlCommand.Parameters.AddWithValue("@Id", CurrencyId);

                                    sqlCommand.ExecuteNonQuery();
                                    sqlConnection.Close();

                                    MessageBox.Show("Data deleted successfully", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                                    ClearMaster();
                                }
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
