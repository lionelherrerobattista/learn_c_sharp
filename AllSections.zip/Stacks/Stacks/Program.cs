﻿// Declaration:
//Stack<int> stack = new Stack<int>();

// Add elements
//stack.Push(1);
//stack.Push(2);
//stack.Push(3);
//stack.Push(1337);

// Peek
//Console.WriteLine($"Top value in the stack is {stack.Peek()}");

// remove item
//int myStackItem;
//if(stack.Count > 0 ) // check if not empty
//{
//    myStackItem = stack.Pop();
//    Console.WriteLine($"Popped item: {myStackItem}");
//    Console.WriteLine($"Top value in the stack is {stack.Peek()}");
//}

//while( stack.Count > 0 )
//{
//    myStackItem = stack.Pop();
//    Console.WriteLine($"Popped item: {myStackItem}");
//}

//Console.WriteLine($"Stack count: {stack.Count}");

// reverse an array
int numberAux;
int i = 0;
int[] numbers = new int[] { 8, 2, 3, 4, 7, 6, 2 };
int[] reversedArray = new int[numbers.Length];
Stack<int> numbersReversed = new Stack<int>();

// add to stack
foreach( int number in numbers )
    numbersReversed.Push( number );

// add to array
while ( numbersReversed.Count > 0 )
{
    numberAux = numbersReversed.Pop();
    reversedArray[i++] = numberAux;
}

Console.WriteLine("Reversed array: ");
foreach ( int number in reversedArray )
    Console.Write(number + " ");
    
