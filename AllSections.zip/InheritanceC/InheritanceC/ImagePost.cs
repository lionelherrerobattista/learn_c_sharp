﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceC
{
    internal class ImagePost : Post
    {
        public string ImageURL { get; set; }

        public ImagePost()
        {

        }

        public ImagePost(string title, string sendByUsername, string imageURL, bool isPublic)
        {
            // parent's properties
            this.ID = GetNextID();
            this.Title = title;
            this.SendByUsername = sendByUsername;
            this.IsPublic = isPublic;

            // own propert
            this.ImageURL = imageURL;
        }

        public override string ToString()
        {
            return $"{this.ID} - {this.Title} - {this.ImageURL} - by {this.SendByUsername}";
        }
    }
}
