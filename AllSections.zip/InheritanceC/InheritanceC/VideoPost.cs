﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;

namespace InheritanceC
{
    internal class VideoPost : Post
    {
        private System.Timers.Timer videoTimer { get; set; }
        protected string VideoURL { get; set; }
        protected int Length { get; set; }
        protected int TimeElapsed { get; set; }
        protected bool IsPlaying { get; set; }

        public VideoPost()
        {

        }

        public VideoPost(string title, bool isPublic, string sendByUsername, string videoURL, int length)
            : base(title, isPublic, sendByUsername)
        {
            this.VideoURL = videoURL;
            this.Length = length;
            this.IsPlaying = false;
            this.TimeElapsed= 0;
        }

        public void Play()
        {
            if(!IsPlaying)
            {
                // start timer
                this.TimeElapsed = 0;
                this.IsPlaying = true;
                videoTimer = new System.Timers.Timer(1000); // in milliseconds
                // write press key to stop
                videoTimer.Elapsed += this.OnTimedEvent;
                videoTimer.AutoReset = true;
                videoTimer.Enabled = true;
                // end at length?
                if (this.Length == this.TimeElapsed)
                {
                    this.Stop();
                }
            }
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            // end at length?
            if (this.Length == this.TimeElapsed)
            {
                this.Stop();
            }
            else
            {
                Console.WriteLine($"The video is playing. Timestamp: {this.TimeElapsed++}s");

            }

        }

        public void Stop()
        {

            // stop timer
            videoTimer.Stop();
            videoTimer.Dispose();

            // write time stopped
            Console.WriteLine($"Stopped at {this.TimeElapsed}s");
            this.IsPlaying = false;
            this.TimeElapsed = 0;
        }

        public override string ToString()
        {
            return $"{this.ID} - {this.Title} - {this.VideoURL} -" +
                $" {this.Length} - by {this.SendByUsername}";
        }
    }
}
