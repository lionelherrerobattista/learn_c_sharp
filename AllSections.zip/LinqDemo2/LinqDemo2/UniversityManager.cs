﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo2
{
    internal class UniversityManager
    {
        public List<University> Universities { get; set; }
        public List<Student> Students { get; set; }

        public UniversityManager()
        {
            Universities = new List<University>();
            Students = new List<Student>();

            Universities.Add(new University { Id = 1, Name = "Yale" });
            Universities.Add(new University { Id = 2, Name = "Beijing Tech" });

            Students.Add(
                new Student
                {
                    Id = 1,
                    Name = "Carla",
                    Gender = "female",
                    Age = 17,
                    UniversityId = 1
                }
            );

            Students.Add(
                new Student
                {
                    Id = 2,
                    Name = "Toni",
                    Gender = "male",
                    Age = 21,
                    UniversityId = 1
                }
            );
            Students.Add(
                new Student
                {
                    Id = 3,
                    Name = "Leyla",
                    Gender = "female",
                    Age = 19,
                    UniversityId = 2
                }
            );
            Students.Add(
                new Student
                {
                    Id = 4,
                    Name = "James",
                    Gender = "male",
                    Age = 25,
                    UniversityId = 2
                }
            );
            Students.Add(
                new Student
                {
                    Id = 5,
                    Name = "Linda",
                    Gender = "female",
                    Age = 22,
                    UniversityId = 2
                }
            );
        }

        public void ShowMaleStudents()
        {
            IEnumerable<Student> maleStudents =
                from student in Students
                where student.Gender == "male"
                select student;

            Console.WriteLine("Male - Students: ");

            foreach (Student student in maleStudents)
                student.Print();
        }

        public void ShowFemaleStudents()
        {
            IEnumerable<Student> femaleStudents =
                from student in Students
                where student.Gender == "female"
                select student;

            Console.WriteLine("Female - Students: ");

            foreach (Student student in femaleStudents)
                student.Print();
        }

        public void SortStudentsByAge()
        {
            IEnumerable<Student> sortedStudents = 
                from student in Students
                orderby student.Age
                select student;

            Console.WriteLine("Students sorted by age");

            foreach (var student in sortedStudents)
                student.Print();
        }

        public void SearchStudentsByUniversityName(string uniName)
        {
            IEnumerable<Student> uniStudents =
                from student in Students
                join university in Universities
                on student.UniversityId equals university.Id
                where university.Name == uniName
                select student;

            Console.WriteLine($"Students from {uniName}");

            foreach(Student student in uniStudents)
                student.Print();
        }

        public void SearchStudentsByUniversityId(int id)
        {
            IEnumerable<Student> uniStudents =
                from student in Students
                join university in Universities
                on student.UniversityId equals university.Id
                where university.Id == id
                select student;

            IEnumerable<University> uni = 
                from university in Universities
                where university.Id == id
                select university;

            Console.WriteLine($"Students from University with id {id}");

            foreach (Student student in uniStudents)
                student.Print();
        }

        public void JoinStudentAndUniversity()
        {
            var newCollection =
                from student in Students
                join university in Universities
                on student.UniversityId equals university.Id
                orderby student.Name
                select new
                {
                    StudentName = student.Name,
                    UniversityName = university.Name
                };

            Console.WriteLine("New Collection: ");

            foreach (var item in newCollection)
            {
                Console.WriteLine($"Student {item.StudentName} " +
                    $"from University {item.UniversityName}");
            }
        }
    }
}
