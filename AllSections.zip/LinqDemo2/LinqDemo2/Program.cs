﻿using LinqDemo2;

UniversityManager universityManager = new UniversityManager();

/*
//universityManager.ShowMaleStudents();
//universityManager.ShowFemaleStudents();
//universityManager.SortStudentsByAge();
universityManager.SearchStudentsByUniversityName("Beijing Tech");

Console.Write("Write the university id:");
string userInput = Console.ReadLine();

if(int.TryParse(userInput, out int id))
{
    universityManager.SearchStudentsByUniversityId(id);
}
else
{
    Console.WriteLine("Incorrect id");
}


int[] numbers = { 30, 12, 4, 3, 12 };
IEnumerable<int> sortedNumbers =
    from number in numbers
    orderby number
    select number;

IEnumerable<int> reverseSorted =
        from number in numbers
        orderby number descending
        select number;
//IEnumerable<int> reverseSorted = sortedNumbers.Reverse();

foreach (int number in reverseSorted)
    Console.WriteLine(number);
*/

universityManager.JoinStudentAndUniversity();