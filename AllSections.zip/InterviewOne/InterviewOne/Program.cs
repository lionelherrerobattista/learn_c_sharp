﻿string kitchen = "~OO~~O~O~O F O~O~~OO~";

int notHungry = 0;
int j = 0;
int k = 0;
// split string
string[] splittedKitchen = kitchen.Split('F');
string leftSide = splittedKitchen[0];
string? rightSide = splittedKitchen.Length > 1 ? splittedKitchen[1] : null;

Console.WriteLine($"Left side string: {leftSide}");
Console.WriteLine($"Right side string: {rightSide}");

// always at least one?
// right from from F
for(int i = 0; i < leftSide.Length; i++)
{
    j = i + 1 < rightSide.Length ? i + 1 : 0;
    k = i + 2 < rightSide.Length ? i + 2 : 0;
    // ~O cats not following, count
    // check current index and current + 1
    if ((j != 0 && k != 0) && (
        rightSide[i].Equals('0')
        && rightSide[j].Equals('~')
        && !rightSide[k].Equals('O'))
    )
        notHungry++;
    else if (
        (j != 0 && k == 0) && (
        rightSide[i].Equals('O')
        && rightSide[j].Equals('~'))
    )
        notHungry++;
    else
        continue;
}

// left from F
if(!string.IsNullOrEmpty(rightSide))
{
    for (int i = 0; i < rightSide.Length; i++)
    {
        j = i + 1 < rightSide.Length ? i+1 : 0;
        k = i + 2 < rightSide.Length ? i+2 : 0;
        // ~O cats not following, count
        // check current index and current + 1
        if ((j != 0 && k != 0) && (
            rightSide[i].Equals('~')
            && rightSide[j].Equals('O')
            && !rightSide[k].Equals('~'))
        )
            notHungry++;
        else if(
            (j != 0 && k == 0) && (
            rightSide[i].Equals('~')
            && rightSide[j].Equals('O'))
        )
            notHungry++;
        else
            continue;
    }
}

Console.WriteLine($"Numbers of hungry cats total {notHungry}");


// ~O  cats not following, count



/*
         public static int NotHungryCats(string kitchen)
        {
            // split the map by position of food
            var cats = kitchen.Replace(" ", "").Split('F');
            
            // count on both sides
            var leftCount = cats[0].Where((x,i) => i % 2 == 1).Count(x => x == '~');     
            var rightCount = cats[1].Where((x,i) => i % 2 == 0).Count(x =>x == '~');
            
            return leftCount + rightCount;
        }
*/