﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Members
    {
        // memeber - private field
        private string _memberName;
        private string _jobTitle;
        private int _salary = 5000;

        // memeber - public field;
        public int age;

        public string JobTitle
        {
            get
            {
                return _jobTitle;
            }
            set
            {
                _jobTitle = value;
            }
        }

        public void Introducing(bool isFriend)
        {
            if(isFriend)
            {
                SharingPrivateInfo();
            }
            else
            {
                Console.WriteLine($"Hi, my name is {_memberName}," +
                    $"and my job title is {JobTitle}. I'm {age} years old.");
            }

        }

        private void SharingPrivateInfo()
        {
            Console.WriteLine($"My salary is {_salary}");
        }

        //memeber constructor

        public Members() {
            age = 30;
            _memberName = "Lucy";
            _salary = 60000;
            JobTitle = "Developer";
            Console.WriteLine("Object created");
        }

        // member - finalizer -destructor
        ~Members()
        {
            //Console.WriteLine("Deconstruction of Member object");
            Debug.Write("Deconstruction of Member object");
        }

    }
}
