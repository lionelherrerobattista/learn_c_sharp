﻿namespace HelloWorld
{
    internal class Car
    {
        // private member variables / fields
        private string _name;
        private int _hp;
        private string _color;
        private int _maxSpeed;

        // Public property
        public string Name
        {
            get { return _name; }
            set
            {
                if (value == "")
                    _name = "Default Name";
                else
                    _name = value;
            }
        }

        public int MaxSpeed
        {
            set
            {
                _maxSpeed = value;
            }
        }


        // Default constructor
        public Car()
        {
            _name = "Car";
            _hp = 0;
            _color = "red";
            Drive();
        }

        // Constructor
        public Car(string name, int hp = 0)
        {
            _name = name;
            _hp = hp;
            _color = "red";
            Console.WriteLine($"{name} was created");
            Drive();
        }

        public Car(string name, int hp = 0, string color = "black")
        {
            _name = name;
            _hp = hp;
            _color = color;
            Console.WriteLine($"{name} was created");
            Drive();
        }


        private void Drive()
        {
            Console.WriteLine($"{_name} is driving");
        }

        public void Stop()
        {
            Console.WriteLine($"{_name} has stopped.");
        }

        public void PrintDetails()
        {
            Console.WriteLine($"Name: {_name}, HP: {_hp}, Color: {_color}");
        }
    }
}
