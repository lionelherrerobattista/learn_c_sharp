﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Class1
    {
        static int highscore = 100;
        static string highscorePlayer = "Juan";

        public static void checkHighscore(int score, string playerName)
        {
            if(score > highscore)
            {
                Console.WriteLine($"New highscore is {score}");
                Console.WriteLine($"New highscore holder is {playerName}");
            }
            else
            {
                Console.WriteLine($"The old highscore of {highscore} could not be broken " +
                    $"and is still held by {highscorePlayer}");
            }
        }

        public static void Login(string username, string password)
        {
            Console.WriteLine("\nLogin:");
            Console.Write("Write username: ");
            string inputUsername = Console.ReadLine();
            Console.Write("Write password: ");
            string inputPassword = Console.ReadLine();

            if (username.Equals(inputUsername)
                && password.Equals(inputPassword))
                Console.WriteLine("Login successful!");
            else
                Console.WriteLine("Wrong username or password");
        }

        public static void Register(out string username, out string password)
        {
            Console.WriteLine("Register:");
            Console.Write("Write username: ");
            username = Console.ReadLine();
            Console.Write("Write password: ");
            password = Console.ReadLine();

        }
    }
}
