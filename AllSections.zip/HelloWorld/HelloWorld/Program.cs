﻿using HelloWorld;


Car myCar = new Car();
myCar.MaxSpeed = 180;
//Console.WriteLine($"Max speed is {myCar.MaxSpeed}");
Members member1 = new Members();
member1.Introducing(true);