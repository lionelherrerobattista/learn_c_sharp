﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LinqToSQL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinqToSQLDataClassesDataContext dataContext;
        public MainWindow()
        {
            InitializeComponent();

            string connectionString = ConfigurationManager.ConnectionStrings["LinqToSQL.Properties.Settings.PanjutorialsDBConnectionString"].ConnectionString;
            dataContext = new LinqToSQLDataClassesDataContext(connectionString);

            //InsertUniversities();
            //InsertStudents();
            //InsertLectures();
            //InsertStudentLecture();
            //GetUniversityOfStudent();
            //GetStudentLectures();
            //GetAllStudentsFromUniversity();
            //GetAllUniversitiesWithGender();
            //GetUniversityLectures();
            //UpdateStudent();
            DeleteStudent();
        
        }


        public void InsertUniversities()
        {
            dataContext.ExecuteCommand("DELETE FROM University");

            // add universities
            University yale = new University();
            yale.Name = "Yale";
            dataContext.Universities.InsertOnSubmit(yale);

            University beijinTech = new University();
            beijinTech.Name = "Beijing Tech";
            dataContext.Universities.InsertOnSubmit(beijinTech);

            University mit = new University();
            mit.Name = "MIT";
            dataContext.Universities.InsertOnSubmit(mit);

            // submit changes
            dataContext.SubmitChanges(); // Insert into db

            // Set it in the WPF
            MainDataGrid.ItemsSource = dataContext.Universities;
        }

        public void InsertStudents()
        {
            dataContext.ExecuteCommand("DELETE FROM Student");

            // retrieve data from db
            University yale = dataContext.Universities.First(un => un.Name.Equals("Yale"));
            University beijingTech = dataContext.Universities.First(un => un.Name.Equals("Beijing Tech"));

            List<Student> students = new List<Student>();

            // add to list
            students.Add(new Student
            {
                Name = "Carla",
                Gender = "female",
                UniversityId = yale.Id
            });
            students.Add(new Student
            {
                Name = "Tony",
                Gender = "Male",
                University = yale
            });
            students.Add(new Student
            {
                Name = "Leyla",
                Gender = "female",
                University = beijingTech
            });
            students.Add(new Student
            {
                Name = "James",
                Gender = "Male",
                University = beijingTech
            });

            // add to data context
            dataContext.Students.InsertAllOnSubmit(students);

            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Students;
        }

        public void InsertLectures()
        {
            dataContext.Lectures.InsertOnSubmit(new Lecture
            {
                Name = "Math",
            });
            dataContext.Lectures.InsertOnSubmit(new Lecture
            {
                Name = "History",
            });


            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Lectures;

        }

        public void InsertStudentLecture()
        {
            // get students
            Student studentOne = dataContext.Students.First(st => st.Name.Equals("Carla"));
            Student studentTwo = dataContext.Students.First(st => st.Name.Equals("Tony"));
            Student studentThree = dataContext.Students.First(st => st.Name.Equals("Leyla"));
            Student studentFour = dataContext.Students.First(st => st.Name.Equals("James"));

            // get lectures
            Lecture math = dataContext.Lectures.First(lc => lc.Name.Equals("Math"));
            Lecture history = dataContext.Lectures.First(lc => lc.Name.Equals("History"));

            // add to student lecture
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture
            {
                Student = studentOne,
                Lecture = math,
            });
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture
            {
                Student = studentTwo,
                Lecture = math,
            });
            dataContext.StudentLectures.InsertOnSubmit(new StudentLecture
            {
                Student = studentFour,
                Lecture = history,
            });

            // another way
            StudentLecture sltwo = new StudentLecture();
            sltwo.Student = studentThree;
            sltwo.Lecture = history;
            dataContext.StudentLectures.InsertOnSubmit(sltwo);

            // submit
            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.StudentLectures;
        }

        public void GetUniversityOfStudent()
        {
            Student studentOne = dataContext.Students.First(st => st.Name.Equals("Tony"));

            University university = studentOne.University;

            // add to list to display
            List<University> universities = new List<University>();
            universities.Add(university);

            MainDataGrid.ItemsSource = universities;
        }

        public void GetStudentLectures()
        {
            Student studentOne = dataContext.Students.First(st => st.Name.Equals("Tony"));

            //var studentLectures = from studentLecture in studentOne.StudentLectures select studentLecture;

            List<StudentLecture> studentLectures = dataContext
                .StudentLectures.Where(lc => lc.StudentId.Equals(studentOne.Id)).ToList();


            List<Lecture> lectures = new List<Lecture>();
            foreach (StudentLecture studentLecture in studentLectures)
            {
                Lecture lecture = studentLecture.Lecture;
                lectures.Add(lecture);
            }

            MainDataGrid.ItemsSource = lectures;
        }

        public void GetAllStudentsFromUniversity()
        {
            var students =
                from student in dataContext.Students
                where student.University.Name.Equals("Yale")
                select student;

            MainDataGrid.ItemsSource = students;

        }

        public void GetAllUniversitiesWithGender()
        {
            var universities = from student in dataContext.Students
                               join university in dataContext.Universities
                               on student.University equals university
                               where student.Gender == "female"
                               select university;


            MainDataGrid.ItemsSource = universities;
        }

        public void GetUniversityLectures()
        {
            var lectures = from studentLecture in dataContext.StudentLectures
                           join student in dataContext.Students
                            on studentLecture.StudentId equals student.Id
                           where student.University.Name == "Beijing Tech"
                           select studentLecture.Lecture;

            MainDataGrid.ItemsSource = lectures;
        }

        public void UpdateStudent()
        {
            Student student = dataContext
                .Students.FirstOrDefault(st => st.Name.Equals("Tony"));

            student.Name = "Antonio";

            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Students;
        }

        public void DeleteStudent()
        {
            Student student = dataContext
                .Students.FirstOrDefault(st => st.Name.Equals("James"));

            dataContext.Students.DeleteOnSubmit(student);

            dataContext.SubmitChanges();

            MainDataGrid.ItemsSource = dataContext.Students;
        }
    }

}

