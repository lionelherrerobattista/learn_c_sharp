﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class UI
    {

        public void PrintUI()
        {
            Console.Write(" ");
            Console.Write(" ");
            Console.Write(" ");

        }

        public void PrintUI2()
        {
            Console.WriteLine("   |   |   ");
            Console.WriteLine($" {1} | {2} | {3} ");
            Console.WriteLine("   |   |   ");
            Console.WriteLine("---|---|---|");


        }


    }
}
