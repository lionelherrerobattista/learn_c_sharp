﻿/*
// Arrays
//int[] grades = new int[5];

//grades[0] = 20;
//grades[1] = 15;
//grades[2] = 12;
//grades[3] = 9;
//grades[4] = 7;

//Console.WriteLine($"Grades at index 0: {grades[0]}");

//string input = Console.ReadLine();
//grades[0] = int.Parse(input);
//Console.WriteLine($"Grades at index 0: {grades[0]}");

//// other ways of initializing
//int[] gradesOfMathStudentsA = { 20, 13, 12, 8, 8 };
//int[] gradesOfMathStudentsB = new int[] { 15, 20, 3, 17, 18, 15 };


int[] nums = new int[10];

for (int i = 0; i<nums.Length;i++)
    nums[i] = i;

for (int i = 0;i< nums.Length; i++)
    Console.WriteLine($"Element {i} = {nums[i]}");

foreach (int num in nums)
    Console.WriteLine(num);


// Multidimensional arrays
// 2D array
string[,] matrix;

// 3D array
string[,,] threeD;

int[,] array2D = new int[,]
{
    {1,2,3},
    {4,5,6},
    {7,8,9}
};

Console.WriteLine($"Central value is {array2D[1, 1]}");
Console.WriteLine($"Lower left value is {array2D[2, 0]}");

string[,,] array3D = new string[,,]
{
    {
        {"000", "001" },
        {"010", "011" }
    },
    {
        {"100", "101" },
        {"110", "111" }
    }
};

Console.WriteLine($"The value is {array3D[1, 1, 0]}");

string[,] array2DString = new string[3, 2] {
    { "one", "two" },
    { "three", "four" },
    { "five", "six" }
};

array2DString[1, 1] = "chicken";
Console.WriteLine(array2DString[1, 1]);

int dimensions = array2DString.Rank;

Console.WriteLine($"The value is {dimensions}");

int[,] array2D2 = { { 1, 2 }, { 3, 4 } };


int[,] matrix =
{
    {1, 2, 3},  // 0,2
    {4, 5, 6},  // 1,1
    {7, 8, 9}   // 2,0
};

//foreach (int item in matrix)
//{
//    Console.Write($"{item} "); // 1 2 3 4 5 6 7 8 9
//}

//for (int i = 0; i < matrix.GetLength(0); i++)
//{
//    for (int j = 0; j < matrix.GetLength(1); j++)
//    {
//        if (i == j) // print diagonal numbers
//            Console.Write($"{matrix[i,j]} ");
//        else
//            Console.Write(" ");
//    }
//    Console.WriteLine(" ");
//}


//for (int i = 0; i < matrix.GetLength(0); i++)
//{
//    Console.Write($"{matrix[i, i]} ");
//    Console.WriteLine(" ");
//}

//int j = matrix.GetLength(1) - 1;
for (int i = 0, j = matrix.GetLength(1) - 1; i < matrix.GetLength(0); i++, j--)
{
    Console.WriteLine(matrix[i, j]);
}
*/

// tic tac toe
using Arrays;

string[,] board =
{
    {"O", "O", "X" },
    {"O", "X", "O" },
    {"O", "X", "X" },
};

bool result = Checker.CheckResult(board);

Console.WriteLine(result);