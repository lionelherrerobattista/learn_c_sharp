﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Checker
    {

        public static bool CheckResult(string[,] board)
        {
            // TODO
            bool hasWon = false;
            int counterX = 0;
            int counterY = 0;

            // horizontal
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for(int j = 0; j < board.GetLength(1); j++)
                {
                    // check symbols
                    if (board[i, j].Equals("X"))
                        counterX++;
                    else if(board[i, j].Equals("O"))
                        counterY++;
                    Console.WriteLine(board[i, j]);
                    Console.WriteLine($"Counters: X: {counterX} Y:{counterY}");
                }

                

                // check result
                if (counterX == 3 || counterY == 3)
                {
                    hasWon = true;
                    break;
                }

                // Restart counter
                counterX = 0;
                counterY = 0;
            }

            // vertical - use do while
            if(!hasWon)
            {
                Console.WriteLine($"Has won: {hasWon}");
                counterX = 0;
                counterY = 0;
                int i = 0;
                int j = 0;
                do
                {
                    // check symbols
                    if (board[i, j].Equals("X"))
                        counterX++;
                    else if (board[i, j].Equals("O"))
                        counterY++;

                    // check result
                    if (counterX == 3 || counterY == 3)
                    {
                        hasWon = true;
                        break;
                    }

                    // increase variable line
                    i++;

                    if (i == 3) // end of lines
                    {
                        i = 0;
                        j++; // next column
                        // Restart counter
                        counterX = 0;
                        counterY = 0;
                    }

                } while (j < 3);
            }

            if(!hasWon)
            {
                // Restart counter
                counterX = 0;
                counterY = 0;

                //diagonal
                for (int i = 0; i < board.GetLength(0); i++)
                {
                    // check symbols
                    if (board[i, i].Equals("X"))
                        counterX++;
                    else if (board[i, i].Equals("O"))
                        counterY++;
                }

                // check result
                if (counterX == 3 || counterY == 3)
                    hasWon = true;

                // Restart counter
                counterX = 0;
                counterY = 0;

                // reverse diagonal
                for (int i = 0, j = board.GetLength(1) - 1; i < board.GetLength(0); i++, j--)
                {
                    // check symbols
                    if (board[i, j].Equals("X"))
                        counterX++;
                    else if (board[i, j].Equals("O"))
                        counterY++;
                }

                // check result
                if (counterX == 3 || counterY == 3)
                    hasWon = true;
            }

            return hasWon;
        }
    }
}
