﻿using System.Text.RegularExpressions;

string pattern = @"\d";
Regex regex = new Regex(pattern);

string text = "Hi there, my number is 123413";

// show all matches
MatchCollection matchCollection = regex.Matches(text);

Console.WriteLine($"{matchCollection.Count} matches found:\n {text}");

foreach(Match match in matchCollection)
{
    GroupCollection group = match.Groups;
    Console.WriteLine($"{group[0].Value} found at {group[0].Index}"); ;
}