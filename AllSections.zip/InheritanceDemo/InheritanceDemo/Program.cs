﻿using InheritanceDemo;

Radio myRadio = new Radio(false, "Sony");
//myRadio.SwitchOn();
myRadio.ListenRadio();

TV myTV = new TV(false, "Samsung");
myTV.SwitchOn();
myTV.WatchTV();