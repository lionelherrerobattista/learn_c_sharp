﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFZooManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlConnection;

        public MainWindow()
        {
            InitializeComponent();

            string connectionString = ConfigurationManager
                   .ConnectionStrings["WPFZooManager.Properties.Settings.PanjutorialsDBConnectionString"]
                   .ConnectionString;

            sqlConnection = new SqlConnection(connectionString);
            ShowZoos();
            ShowAllAnimals();
        }

        private void ShowZoos()
        {
            try
            {
                string query = "SELECT * FROM Zoo";
                SqlDataAdapter adapter = new SqlDataAdapter(query, sqlConnection);

                using (adapter)
                {
                    DataTable zooTable = new DataTable();

                    adapter.Fill(zooTable);

                    // load list
                    listZoos.DisplayMemberPath = "Location"; // what is shown
                    listZoos.SelectedValue = "Id"; // value linked when selected
                    listZoos.ItemsSource = zooTable.DefaultView; // reference to data
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void ShowAllAnimals()
        {
            try
            {
                string query = "SELECT * FROM Animal";
                SqlDataAdapter adapter = new SqlDataAdapter(query, sqlConnection);

                using (adapter)
                {
                    DataTable animalTable = new DataTable();

                    adapter.Fill(animalTable);

                    // load list
                    listAnimals.DisplayMemberPath = "Name";
                    listAnimals.SelectedValue = "Id";
                    listAnimals.ItemsSource = animalTable.DefaultView;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                throw;
            }
        }

        private void ShowAssociatedAnimals()
        {
            try
            {
                string query = @"
                    SELECT * FROM Animal AS a 
                    INNER JOIN ZooAnimal AS za 
                        ON a.Id = za.AnimalId 
                    WHERE za.ZooId = @ZooId"; // set variable

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);

                using (adapter)
                {

                    DataRowView drw = (DataRowView)listZoos.SelectedValue;
                    if (drw != null)
                    {
                        sqlCommand.Parameters.AddWithValue("@ZooId", drw["Id"].ToString()); // we pass the selected zoo id

                        DataTable animalTable = new DataTable();

                        adapter.Fill(animalTable);

                        // load list
                        listAssociatedAnimals.DisplayMemberPath = "Name"; // what is shown
                        listAssociatedAnimals.SelectedValue = "Id"; // value linked when selected
                        listAssociatedAnimals.ItemsSource = animalTable.DefaultView; // reference to data
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void ShowSelectedZooInTextBox()
        {
            try
            {
                string query = @"
                    SELECT Location FROM Zoo 
                    WHERE Id = @ZooId";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);

                using (adapter)
                {

                    DataRowView drw = (DataRowView)listZoos.SelectedValue;
                    if (drw != null)
                    {
                        sqlCommand.Parameters.AddWithValue("@ZooId", drw["Id"].ToString()); // we pass the selected zoo id

                        DataTable zooTable = new DataTable();

                        adapter.Fill(zooTable);

                        myTextBox.Text = zooTable.Rows[0]["Location"].ToString();
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void ShowSelectedAnimalInTextBox()
        {
            try
            {
                string query = @"
                    SELECT Name FROM Animal 
                    WHERE Id = @AnimalId";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);

                using (adapter)
                {

                    DataRowView drw = (DataRowView)listAnimals.SelectedValue;
                    if (drw != null)
                    {
                        sqlCommand.Parameters.AddWithValue("@AnimalId", drw["Id"].ToString()); // we pass the selected zoo id

                        DataTable animalTable = new DataTable();

                        adapter.Fill(animalTable);

                        myTextBox.Text = animalTable.Rows[0]["Name"].ToString();
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void listZoos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowAssociatedAnimals();
            ShowSelectedZooInTextBox();
        }

        private void ListAnimals_SelectionChanged(object sender, SelectionChangedEventArgs args)
        {
            ShowSelectedAnimalInTextBox();
        }

        private void DeleteZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                DELETE FROM Zoo
                WHERE Id = @ZooId";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drw = (DataRowView)listZoos.SelectedValue;

                if (drw != null)
                {
                    sqlCommand.Parameters.AddWithValue("@ZooId", drw["Id"].ToString());
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowZoos();
            }
        }

        private void AddZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    INSERT INTO Zoo (
                        Location
                    )
                    VALUES (
                        @Location
                    )";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                sqlCommand.Parameters.AddWithValue("@Location", myTextBox.Text);
                sqlCommand.ExecuteScalar();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowZoos();
            }
        }

        private void AddAnimalToZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                INSERT INTO ZooAnimal (
                    ZooId,
                    AnimalId
                )
                VALUES (
                    @ZooId,
                    @AnimalId
                )";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drwlistZoos = (DataRowView)listZoos.SelectedValue;
                DataRowView drwlistAnimals = (DataRowView)listAnimals.SelectedValue;

                if (drwlistZoos != null && drwlistAnimals != null)
                {
                    sqlCommand.Parameters.AddWithValue("@ZooId", drwlistZoos["Id"].ToString());
                    sqlCommand.Parameters.AddWithValue("@AnimalId", drwlistAnimals["Id"].ToString());
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowAssociatedAnimals();
            }
        }
        
        private void UpdateZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                UPDATE Zoo
                    SET Location = @Location
                WHERE Id = @ZooId";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drwlistZoos = (DataRowView)listZoos.SelectedValue;

                if (drwlistZoos != null)
                {
                    sqlCommand.Parameters.AddWithValue("@ZooId", drwlistZoos["Id"].ToString());
                    sqlCommand.Parameters.AddWithValue("@Location", myTextBox.Text);
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowZoos();
            }
        }        
        private void UpdateAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                UPDATE Animal
                    SET Name = @Name
                WHERE Id = @AnimalId";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drwlistAnimals = (DataRowView)listAnimals.SelectedValue;

                if (drwlistAnimals != null)
                {
                    sqlCommand.Parameters.AddWithValue("@AnimalId", drwlistAnimals["Id"].ToString());
                    sqlCommand.Parameters.AddWithValue("@Name", myTextBox.Text);
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowAllAnimals();
            }
        }

        public void RemoveAnimal_Click (object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    DELETE FROM ZooAnimal
                    WHERE AnimalId = @AnimalId
                ";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drw = (DataRowView)listAssociatedAnimals.SelectedValue;

                if (drw != null)
                {
                    sqlCommand.Parameters.AddWithValue("@AnimalId", drw["Id"].ToString());
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowAssociatedAnimals();
            }
        }

        public void AddAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    INSERT INTO Animal (
                        Name
                    )
                    VALUES (
                        @Name
                    )";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                sqlCommand.Parameters.AddWithValue("@Name", myTextBox.Text);
                sqlCommand.ExecuteScalar();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowAllAnimals();
            }
        }

        public void DeleteAnimal_Click(Object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    DELETE FROM Animal
                    WHERE Id = @AnimalId
                ";

                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                // other way
                sqlConnection.Open();

                // execute code
                DataRowView drw = (DataRowView)listAnimals.SelectedValue;

                if (drw != null)
                {
                    sqlCommand.Parameters.AddWithValue("@AnimalId", drw["Id"].ToString());
                    sqlCommand.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close();
                ShowAllAnimals();
            }
        }
    }
}
