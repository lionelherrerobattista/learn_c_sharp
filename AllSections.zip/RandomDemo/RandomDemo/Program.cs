﻿Random dice = new Random();
int numSides;

for (int i = 0; i < 10; i++)
{
    numSides = dice.Next(1, 7);
    Console.WriteLine(numSides);
}
int yesNoMaybe;

Console.WriteLine("Please enter your question?");
Console.ReadLine();

yesNoMaybe = dice.Next(1, 4);

if (yesNoMaybe == 1)
{
    Console.WriteLine("Yes");
}
else if (yesNoMaybe == 2)
{
    Console.WriteLine("No");
}
else
{
    Console.WriteLine("Maybe");
}
