﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    internal class Helper
    {

        public static Func<float, float, float> Plus = (a, b) => a + b;
        public static Func<float, float, float> Minus = (a, b) => a - b;
        public static Func<float, float, float> Multiply = (a, b) => a * b;
        public static Func<float, float, float> Divide = (a, b) => a / b;

        // lambdas
        static Dictionary<string, Func<float, float, float>> LambdaDict = new Dictionary<string, Func<float, float, float>>()
        {
            { "+", Helper.Plus },
            { "-", Helper.Minus },
            { "*", Helper.Multiply },
            { "/", Helper.Divide },
        };

        public delegate bool FilterDelegate(Person p);

        public delegate float OperationDelegate(float a, float b);

        //public static float Add(float a, float b)
        //{
        //    return a + b;
        //}
        //public static float Subtract(float a, float b)
        //{
        //    return a - b;
        //}
        //public static float Multiply(float a, float b)
        //{
        //    return a * b;
        //}
        //public static float Divide(float a, float b)
        //{
        //    return a / b;
        //}

        public static float ApplyOperation(float a, float b, OperationDelegate operation)
        {
            return operation(a, b);
        }

        // filters
        public static bool IsMinor(Person p)
        {
            return p.Age < 18;
        }

        public static bool IsAdult(Person p)
        {
            return p.Age >= 18;
        }

        public static bool IsSenior(Person p)
        {
            return p.Age >= 65;
        }


        public static void DisplayPeople(string title, List<Person> people, FilterDelegate filter)
        {
            Console.WriteLine(title);

            foreach (Person person in people)
            {
                if (filter(person))
                {
                    Console.WriteLine($"{person.Name}, {person.Age}");
                }
            }
        }

        public static bool Filter(string s)
        {
            return s.Contains("i");
        }


        public static Func<float, float, float> OperationGet(string op)
        {
            if(LambdaDict.ContainsKey(op))
            {
                return LambdaDict[op];
            }
            else
            {
                return null;
            }

        }
    }

}
