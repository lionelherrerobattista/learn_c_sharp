﻿using DelegatesDemo;
/*
List<string> names = new List<string>() { "Aiden", "Sif", "Walter", "Anatoli" };

Console.WriteLine("-----before-----");
foreach (string name in names)
{
    Console.WriteLine(name);
}


names.RemoveAll(Helper.Filter);

Console.WriteLine("-----after-----");
foreach (string name in names)
{
    Console.WriteLine(name);
}
*/

// creating own delegates
Person p1 = new Person() { Name = "Aiden", Age = 41 };
Person p2 = new Person() { Name = "Sif", Age = 69 };
Person p3 = new Person() { Name = "Walter", Age = 12 };
Person p4 = new Person() { Name = "Anatoli", Age = 25 };

List<Person> people = new List<Person>() { p1, p2, p3, p4 };

Helper.DisplayPeople("Kids", people, Helper.IsMinor);
Helper.DisplayPeople("\nAdults:", people, Helper.IsAdult);
Helper.DisplayPeople("\nSeniors:", people, Helper.IsSenior);

Helper.FilterDelegate filter = delegate (Person p)
{
    return p.Age >= 20 && p.Age <= 30;
};

Helper.DisplayPeople("\nBetween 20 and 30:", people, filter);

Helper.DisplayPeople("All: ", people, delegate (Person p)
{
    return true;
});

string searchKeyword = "A";
Helper.DisplayPeople($"\nAge > 20 with search keyword {searchKeyword}", people, (p) =>
{
    if (p.Name.Contains(searchKeyword) && p.Age > 20)
    {
        return true;
    }
    else
    {
        return false;
    }
});

Helper.DisplayPeople("\nExactly 25: ", people, p => p.Age == 25);

Func<float, float, float> func = Helper.OperationGet("+");
float result;

if(func != null)
{
    result = func(2, 2);
    Console.WriteLine($"\nResult: {result}");
} else
{
    Console.WriteLine(func);
    Console.WriteLine("func is null");
}