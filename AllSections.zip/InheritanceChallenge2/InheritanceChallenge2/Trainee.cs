﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceChallenge2
{
    internal class Trainee : Employee
    {
        protected int WorkingHours { get; set; }
        protected int SchoolHours { get; set; }

        public Trainee(string name, string firstName, int salary, int workingHours, int schoolHours) 
            : base(name, firstName, salary)
        {
            WorkingHours = workingHours;
            SchoolHours = schoolHours;
        }

        public override void Work()
        {
            Console.WriteLine($"Trainee working hours: {WorkingHours}"); ;
        }


        public void Learn()
        {
            Console.WriteLine($"Trainee's learning hours: {SchoolHours}");
        }
    }
}
