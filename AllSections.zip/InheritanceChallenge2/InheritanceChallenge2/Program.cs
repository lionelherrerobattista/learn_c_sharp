﻿using InheritanceChallenge2;

Employee employee = new Employee("Perez", "Juan", 1200);
Trainee trainee = new Trainee("Rodriguez", "Jose", 500, 6, 4);
Boss boss = new Boss("García", "Maria", 2000, "BMW");

boss.Lead();
trainee.Work();