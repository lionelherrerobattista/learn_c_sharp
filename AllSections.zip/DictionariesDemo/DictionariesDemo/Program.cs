﻿// declaration
using DictionariesDemo;
using System.Collections.Generic;

/*
Employee[] employees =
{
    new Employee("CEO", "Gwyn", 95, 200),
    new Employee("Manager", "Joe", 35, 25),
    new Employee("HR", "Lora", 32, 21),
    new Employee("Secretary", "Petra", 28, 18),
    new Employee("Lead Developer", "Artoria", 55, 35),
    new Employee("Intern", "Ernest", 22, 8),
};


Dictionary<string, Employee> employeesDirectory = new Dictionary<string, Employee>();

foreach (Employee employee in employees)
{
    employeesDirectory.Add(employee.Role, employee);
}

// Get data
//string key = "CTO";
//if(employeesDirectory.ContainsKey(key))
//{
//    Employee empl = employeesDirectory[key];
//    Console.WriteLine($"Employee Name: {empl.Name}, Role: {empl.Role}, Salary: {empl.Salary}");
//} 
//else
//{
//    Console.WriteLine($"No employee found with this Key {key}");
//}

//Employee result = null;

//if(employeesDirectory.TryGetValue("Intern", out result))
//{
//        Console.WriteLine($"Employee Name: {result.Name}, Role: {result.Role}," +
//            $" Salary: {result.Salary}");
//} 
//else
//{
//    Console.WriteLine($"No employee found with this Key {key}");
//}


//update
string keyToUpdate = "HR";
if (employeesDirectory.ContainsKey(keyToUpdate))
{
    employeesDirectory[keyToUpdate] = new Employee("HR", "Eleka", 26, 18);
    Console.WriteLine($"Employee with this Key {keyToUpdate} was updated");
}
else
{
    Console.WriteLine($"No employee found with this Key {keyToUpdate}");
}

// Remove

string keyToRemove = "Intern";

if (employeesDirectory.Remove(keyToRemove))
{
    Console.WriteLine($"Employee with this Key {keyToRemove} was removed");
}
else
{
    Console.WriteLine($"No employee found with this Key {keyToRemove}");
}


// loop
for (int i = 0; i < employeesDirectory.Count; i++)
{
    // return key-value pair stored at index i
    KeyValuePair<string, Employee> keyValuePair = employeesDirectory.ElementAt(i);
    Console.WriteLine($"Key: {keyValuePair.Key}");

    Employee employeeValue = keyValuePair.Value;
    Console.WriteLine($"Employee Name: {employeeValue.Name}, Role: {employeeValue.Role}," +
            $" Salary: {employeeValue.Salary}");
}
*/

int i = 0;
string returnValue;

Dictionary<int, string> numbersDictionary = new Dictionary<int, string>()
{
    {0, "zero" },
    {1, "one" },
    {2, "two" },
    {3, "three" },
    {4, "four" },
    {5, "five" }
};


if (numbersDictionary.ContainsKey(i))
{
    returnValue = numbersDictionary[i];
}
else
{
    returnValue = "nope";
}