﻿using Hashtables;
using System.Collections;

/*
Hashtable studentsTable = new Hashtable();

Student stud1 = new Student(1, "Maria", 98);
Student stud2 = new Student(2, "Jason", 76);
Student stud3 = new Student(3, "Clara", 46);
Student stud4 = new Student(4, "Steve", 55);

// add values
studentsTable.Add(stud1.Id, stud1);
studentsTable.Add(stud2.Id, stud2);
studentsTable.Add(stud3.Id, stud3);
studentsTable.Add(stud4.Id, stud4);

// retrieve values
//Student storedStudent1 = (Student) studentsTable[stud1.Id];

//Console.WriteLine($"Student Id: {storedStudent1.Id}, Name: {storedStudent1.Name}, " +
//    $"GPA: {storedStudent1.GPA}");

// retrieve all values
foreach (DictionaryEntry entry in studentsTable)
{
    Student tempStudent = (Student)entry.Value;

    Console.WriteLine($"Student Id: {tempStudent.Id}, Name: {tempStudent.Name}, " +
    $"GPA: {tempStudent.GPA}");
}

foreach (Student value in studentsTable.Values)
{
    Console.WriteLine($"Student Id: {value.Id}, Name: {value.Name}, " +
    $"GPA: {value.GPA}");
}
*/
Student[] students = new Student[5];
students[0] = new Student(1, "Denis", 88);
students[1] = new Student(2, "Olaf", 97);
students[2] = new Student(6, "Ragner", 65);
students[3] = new Student(1, "Luise", 73);
students[4] = new Student(4, "Levi", 58);

Hashtable studentList = new Hashtable();

foreach (var student in students)
{
    if (!studentList.ContainsKey(student.id))
        studentList.Add(student.Id, student);
    else
        Console.WriteLine("Sorry, a student with the same ID already exists");
}