﻿using System.Xml.Linq;

string studentsXML =
    @"<Students>
        <Student>
            <Name>Toni</Name>
            <Age>21</Age>
            <University>Yale</University>
            <Semester>3</Semester>
        </Student>
        <Student>
            <Name>Carla</Name>
            <Age>17</Age>
            <University>Yale</University>
            <Semester>1</Semester>
        </Student>
        <Student>
            <Name>Leyla</Name>
            <Age>19</Age>
            <University>Beijing Tech</University>
            <Semester>2</Semester>
        </Student>
        <Student>
            <Name>Paul</Name>
            <Age>18</Age>
            <University>Beijing Tech</University>
            <Semester>2</Semester>
        </Student>
    </Students>";

XDocument studentsXDoc = new XDocument();
studentsXDoc = XDocument.Parse(studentsXML);

var students = from student in studentsXDoc.Descendants("Student") //check every student
               select new
               {
                   Name = student.Element("Name").Value,
                   Age = student.Element("Age").Value,
                   University = student.Element("University").Value,
                   Semester = student.Element("Semester").Value
               };

foreach (var student in students)
    Console.WriteLine($"Student {student.Name} with age {student.Age}" +
        $" from University {student.University} in the {student.Semester}° semester");

var sortedStudents = from student in students
                     orderby student.Age
                     select student;

Console.WriteLine("\nSorted students:");

foreach (var student in sortedStudents)
    Console.WriteLine($"Student {student.Name} with age {student.Age}" +
        $" from University {student.University} in the {student.Semester}° semester");

