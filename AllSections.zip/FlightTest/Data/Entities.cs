﻿using Domain;
using Microsoft.EntityFrameworkCore;

namespace Data
{
    public class Entities : DbContext
    {
        public DbSet<Flight> Flights => Set<Flight>();

        public Entities(DbContextOptions options) : base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Flight>().HasKey(f => f.Id); // set primary key

            modelBuilder.Entity<Flight>().OwnsMany(f => f.BookingList); // has many bookings

            base.OnModelCreating(modelBuilder);
        }

    }
}
