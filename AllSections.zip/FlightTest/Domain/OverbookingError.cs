﻿namespace Domain
{
    public class OverbookingError
    {

    }
}
