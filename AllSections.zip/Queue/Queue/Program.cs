﻿/*
// Declaration:
Queue<int> queue = new Queue<int>();

// add element
queue.Enqueue(1);
queue.Enqueue(2);
queue.Enqueue(3);

// remove first element
int queueItem;

if(queue.Count > 0)
    queueItem = queue.Dequeue();

// peek first element
Console.WriteLine($"The value at the front of the queue is: {queue.Peek()}");

// remove loop
while(queue.Count > 0)
{
    Console.WriteLine($"The front value is {queue.Dequeue()}");
    Console.WriteLine($"The current count is {queue.Count}");
}

// real world example
*/
using Queue;

Queue<Order> ordersQueue = new Queue<Order>();

// enqueue orders
foreach (var order in Order.ReceiveOrdersFromBranch1())
{
    ordersQueue.Enqueue(order);
}

foreach (var order in Order.ReceiveOrdersFromBranch2())
{
    ordersQueue.Enqueue(order);
}

// process orders in queue order
while (ordersQueue.Count > 0)
{
    // remove order at the front
    // store in current order
    Order currentOrder = ordersQueue.Dequeue();
    
    // process current order
    currentOrder.ProcessOrder();
}