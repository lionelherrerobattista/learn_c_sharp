﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue
{
    internal class Order
    {

        public int OrderId { get; set; }
        public int OrderQuantity { get; set; }

        public Order(int orderId, int orderQuantity)
        {
            this.OrderId = orderId;
            this.OrderQuantity = orderQuantity;
        }

        public void ProcessOrder()
        {
            Console.WriteLine($"Order {OrderId} was processed!");
        }

        public static Order[] ReceiveOrdersFromBranch1()
        {
            Order[] orders = new Order[]{
                new Order(1,5),
                new Order(2,4),
                new Order(6,10),
            };

            return orders;
        }
        public static Order[] ReceiveOrdersFromBranch2()
        {
            Order[] orders = new Order[]{
                new Order(3,5),
                new Order(4,4),
                new Order(5,10),
            };

            return orders;
        }

    }
}
