﻿/*
// jagged arrays
// declare
int[][] jaggedArray = new int[3][];

// assign values 1
jaggedArray[0] = new int[5];
jaggedArray[1] = new int[3];
jaggedArray[2] = new int[2];

// assign values 2
jaggedArray[0] = new int[] { 2, 3, 5, 7, 11 };
jaggedArray[1] = new int[] { 1, 2, 3 };
jaggedArray[2] = new int[] { 12, 21 };

// declare and assign
int[][] jaggedArray2 = new int[][]
{
    new int[] {2, 3, 5, 7, 11},
    new int[] {1, 2, 3}
};

Console.WriteLine($"The value in the middle of the first entry is {jaggedArray2[0][2]}"); // 5

foreach(int[] innerArray in jaggedArray2)
{
    foreach(int value in innerArray)
    {
        Console.WriteLine($"{value} ");
    }
}


string[] familyOne = new string[] { "Juan", "Maria" };
string[] familyTwo= new string[] { "Jose", "Laura" };
string[] familyThree = new string[] { "Roberto", "Alicia" };

string[][] friends = new string[][]
{
    familyOne,
    familyTwo,
    familyThree,
};

Console.WriteLine($"Hi {friends[0][1]} this is {friends[2][1]}");
Console.WriteLine($"Hi {friends[1][1]} this is {friends[2][0]}");
Console.WriteLine($"Hi {friends[2][0]} this is {friends[0][0]}");


using JaggedArray;

int[] studentGrades = new int[] { 15, 13, 8, 12, 6, 16 };
double averageResult = Helper.GetAverage(studentGrades);

foreach (var grade in studentGrades)
{
    Console.WriteLine($"  {grade}  ");
}

Console.WriteLine($"The average is {averageResult}");

*/

//using JaggedArray;

//Helper.ParamsMethod("This", "is", "a", "long", "sentence");
//Helper.ParamsMethod("This", "is", "a");

using JaggedArray;

//Helper.ParamsMethod2(50, 3.14f, '@', "The Hobbit");
int min = Helper.MinV2(6, 4, 2, 8, 0, -11, 5);
Console.WriteLine($"The minimum is {min}");
