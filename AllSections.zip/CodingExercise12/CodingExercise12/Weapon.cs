﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingExercise12
{
    internal class Weapon
    {
        public string Name { get; set; }

        public void Label()
        {
            Console.WriteLine($"This is {Name}!");
        }
    }
}
