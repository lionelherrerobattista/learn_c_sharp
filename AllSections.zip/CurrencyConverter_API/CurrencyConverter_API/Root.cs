﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverter_API
{
    internal class Root
    {
        public Rate rates { get; set; }
        public long timestamp;
        public string license;

    }
}
