﻿using EventsAndMulticastDelegates;

AudioSystem audioSystem = new AudioSystem();

RenderingEngine renderingEngine = new RenderingEngine();

Player player1 = new Player("SteelCow");
Player player2 = new Player("DoggoSilva");
Player player3 = new Player("DragonDog");

GameEventManager.TriggerGameStart();

Console.WriteLine("Game is Running... Press any key to end the game.");

// pause
Console.Read();

// shut down the rendering engine and the audio system
GameEventManager.TriggerGameOver();