﻿using EnumDemo;

Day fr = Day.Fr;
Day su = Day.Su;

Day a = Day.Fr;

Console.WriteLine(fr == a); // true
Console.WriteLine(Day.Mo); // Mo
Console.WriteLine((int)Day.Mo); // 0