﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumDemo
{
    enum Day { Mo = 1, Tu, We, Th, Fr, Sa, Su };

    internal class Helper
    {
    }
}
