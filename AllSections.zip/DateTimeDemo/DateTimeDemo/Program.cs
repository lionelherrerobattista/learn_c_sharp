﻿using DateTimeDemo;

DateTime dateTime = new DateTime(1988, 11, 28);

Console.WriteLine($"My birthday is {dateTime}");

// Write tiday on screen
Console.WriteLine(DateTime.Today);

// write current time
Console.WriteLine(DateTime.Now);

// Following day
DateTime tomorrow = Helper.GetTomorrow();
Console.WriteLine($"Tomorrow will be the {tomorrow}");

// day of the week
Console.WriteLine(DateTime.Today.DayOfWeek);

Console.WriteLine(Helper.GetFirstDayOfYear(1999));

// Days in month
int days = DateTime.DaysInMonth(2001, 2);
Console.WriteLine($"Days in Feb 2001: {days}");

// specific time
DateTime now = DateTime.Now;
Console.WriteLine($"Minute is {now.Minute}");

Console.WriteLine($"{now.Hour} o'clock {now.Minute} minutes and {now.Second} seconds");

//Console.WriteLine("");
//Console.WriteLine("Write a date in this format: yyyy-mm-dd");
//string input = Console.ReadLine();
//if(DateTime.TryParse(input, out dateTime))
//{
//    Console.WriteLine(dateTime);
//    TimeSpan daysPassed = now.Subtract(dateTime);
//    Console.WriteLine($"Days passed since {daysPassed.Days}");
//}



Console.WriteLine("");
Console.WriteLine("Write your birth date: yyyy-mm-dd");
string input = Console.ReadLine();
if (DateTime.TryParse(input, out dateTime))
{
    Console.WriteLine(dateTime);
    TimeSpan daysPassed = now.Subtract(dateTime);
    Console.WriteLine($"You are {daysPassed.Days} days old.");
}