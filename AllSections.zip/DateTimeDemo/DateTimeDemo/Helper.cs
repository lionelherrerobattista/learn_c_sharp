﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeDemo
{
    internal class Helper
    {
        public static DateTime GetTomorrow()
        {
            return DateTime.Today.AddDays(1);
        }

        public static DateTime GetFirstDayOfYear(int year)
        {
            return new DateTime(year, 1, 1);
        }
    }
}
