﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeTicTacToe
{
    internal class TicTacToe
    {
        public string[,] board { get; set; }
        public int turn { get; set; }
        public bool hasWon { get; set; }
        public Player playerOne { get; set; }
        public Player playerTwo { get; set; }
        public Player currentPlayer { get; set; }

        public TicTacToe() { 
            board = new string[3, 3]
            {
                {"1","2","3" },
                {"4","5","6" },
                {"7","8","9" }
            };
            turn = 1;
            hasWon = false;
            playerOne = new Player("1", "X");
            playerTwo = new Player("2", "O");
            currentPlayer = playerOne;
        }

        public bool UpdateBoard(int place, Player currentPlayer)
        {
            string value = currentPlayer.symbol;
            bool wasUpdated = true;

            switch (place)
            {
                case 1:
                    if(CheckPlace(board[0, 0]))
                        board[0, 0] = value;
                    else
                        wasUpdated = false;
                    break;
                case 2:
                    if (CheckPlace(board[0, 1]))
                        board[0, 1] = value;
                    else
                        wasUpdated = false;
                    break;
                case 3:
                    if (CheckPlace(board[0, 2]))
                        board[0, 2] = value;
                    else
                        wasUpdated = false;
                    break;
                case 4:
                    if (CheckPlace(board[1, 0]))
                        board[1, 0] = value;
                    else
                        wasUpdated = false;
                    break;
                case 5:
                    if (CheckPlace(board[1, 1]))
                        board[1, 1] = value;
                    else
                        wasUpdated = false;
                    break;
                case 6:
                    if (CheckPlace(board[1, 2]))
                        board[1, 2] = value;
                    else
                        wasUpdated = false;
                    break;
                case 7:
                    if (CheckPlace(board[2, 0]))
                        board[2, 0] = value;
                    else
                        wasUpdated = false;
                    break;
                case 8:
                    if (CheckPlace(board[2, 1]))
                        board[2, 1] = value;
                    else
                        wasUpdated = false;
                    break;
                case 9:
                    if (CheckPlace(board[2, 2]))
                        board[2, 2] = value;
                    else
                        wasUpdated = false;
                    break;
            }

            return wasUpdated;

        }

        private bool CheckPlace(string value)
        {
            bool isValidPlace = value.Equals("X") || value.Equals("O") ? false : true;

            return isValidPlace;
        }

    }
}
