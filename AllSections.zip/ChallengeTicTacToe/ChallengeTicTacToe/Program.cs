﻿using ChallengeTicTacToe;

string userInput;
int option;
bool isValid;
bool isValidPlace;
bool isPlaying = true;
TicTacToe ticTacToe = new TicTacToe();



// print updated ui for next player
UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon);

do
{

    isValid = int.TryParse(Console.ReadLine(), out option);

    if (isValid)
    {
        if(option >= 1 && option <= 9)
        {
            // add new symbol to board
            isValidPlace = ticTacToe.UpdateBoard(option, ticTacToe.currentPlayer);

            if (!isValidPlace)
            {
                UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon, "The place is already occupied. Try again!");
                continue;
            }

            // check if player won
            // finish game
            ticTacToe.hasWon = Checker.CheckResult(ticTacToe.board);

            if(ticTacToe.hasWon)
            {
                UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon);
                Console.Write("Press r to restart or other key to exit: ");
                userInput = Console.ReadLine();

                if (userInput.Equals("r")) // restart
                {
                    ticTacToe = new TicTacToe();
                    UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon);
                    continue;
                }
                else // quit game
                    break;
            }

            // switch player
            ticTacToe.currentPlayer = ticTacToe.currentPlayer.name.Equals("1") ? ticTacToe.playerTwo : ticTacToe.playerOne;
            UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon);
        }
        else
        {
            UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon, "You must input a number between 1 and 9");
        }
    }
    else
    {
        UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon, "You must input a valid number");
    }

    ticTacToe.turn++;

    if (ticTacToe.turn > 9)
    {
        UI.PrintLoseMessage();
        Console.Write("Press r to restart: ");
        userInput = Console.ReadLine();

        if (userInput.Equals("r")) // restart
        {
            ticTacToe = new TicTacToe();
            UI.PrintUI(ticTacToe.board, ticTacToe.currentPlayer, ticTacToe.hasWon);
            continue;
        }
        else // quit game
            break;
    }

    if (option == -1)
    {
        isPlaying = false;
        break;
    }

} while (isPlaying);