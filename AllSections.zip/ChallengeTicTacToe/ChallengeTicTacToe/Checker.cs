﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeTicTacToe
{
    internal class Checker
    {

        public static bool CheckResult(string[,] board)
        {
            // TODO
            bool hasWon = false;

            // horizontal
            hasWon = checkHorizontal(board) || checkVertical(board) || checkDiagonals(board);

            return hasWon;
        }

        private static bool checkHorizontal(string[,] board)
        {
            // TODO
            bool hasWon = false;
            int counterX = 0;
            int counterY = 0;

            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    // check symbols
                    if (board[i, j].Equals("X"))
                        counterX++;
                    else if (board[i, j].Equals("O"))
                        counterY++;
                }

                // check result
                if (counterX == 3 || counterY == 3)
                {
                    hasWon = true;
                    break;
                }

                // Restart counter end of iteration
                counterX = 0;
                counterY = 0;
            }

            return hasWon;
        }

        public static bool checkVertical(string[,] board)
        {
            bool hasWon = false;
            int counterX = 0;
            int counterY = 0;
            int i = 0;
            int j = 0;

            do
            {
                // check symbols
                if (board[i, j].Equals("X"))
                    counterX++;
                else if (board[i, j].Equals("O"))
                    counterY++;

                // check result
                if (counterX == 3 || counterY == 3)
                {
                    hasWon = true;
                    break;
                }

                // increase variable line
                i++;

                if (i == 3) // end of lines
                {
                    i = 0;
                    j++; // next column
                    
                    // Restart counter for next line
                    counterX = 0;
                    counterY = 0;
                }

            } while (j < 3);

            return hasWon;
        }

        private static bool checkDiagonals(string[,] board)
        {
            return checkDiagonal(board) || checkReverseDiagonal(board);
        }

        private static bool checkDiagonal(string[,] board)
        {
            bool hasWon = false;
            int counterX = 0;
            int counterY = 0;

            //diagonal
            for (int i = 0; i < board.GetLength(0); i++)
            {
                // check symbols
                if (board[i, i].Equals("X"))
                    counterX++;
                else if (board[i, i].Equals("O"))
                    counterY++;
            }

            // check result
            if (counterX == 3 || counterY == 3)
                hasWon = true;

            return hasWon;
        }

        private static bool checkReverseDiagonal(string[,] board)
        {
            bool hasWon = false;
            int counterX = 0;
            int counterY = 0;

            // reverse diagonal
            for (int i = 0, j = board.GetLength(1) - 1; i < board.GetLength(0); i++, j--)
            {
                // check symbols
                if (board[i, j].Equals("X"))
                    counterX++;
                else if (board[i, j].Equals("O"))
                    counterY++;
            }

            // check result
            if (counterX == 3 || counterY == 3)
                hasWon = true;

            return hasWon;
        }
    }
}
