﻿int[] nums = new int[]{ 1, 1, 2, 3, 4, 5, 1, 3, 0 };
int pairs = 0;
int sum = 0;
int sumToFind = 2;
int numOne = int.MaxValue;
int numTwo = int.MaxValue;

// iterate sum array
for (int i = 0; i < nums.Length - 1; i++)
{
    // sum current number and next
    sum = nums[i] + nums[i + 1];

    // check if 
    if (sum == sumToFind 
        && (
            numOne != nums[i] 
            && numTwo != nums[i + 1]
    ))
    {
        numOne = nums[i];
        numTwo = nums[i + 1];
        pairs++;
    }  
}

Console.WriteLine(pairs);