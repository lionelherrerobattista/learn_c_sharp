﻿using IEnumerableAndIEnumeratorDemo;

DogShelter shelter = new DogShelter();

foreach (Dog dog in shelter)
{
    if (!dog.IsNaughtyDog)
        dog.GiveTreat(2);
    else
        dog.GiveTreat(1);
}