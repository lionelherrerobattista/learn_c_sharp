﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableAndIEnumeratorDemo
{
    internal class DogShelter : IEnumerable<Dog>
    {
        public List<Dog> dogs;

        public DogShelter()
        {
            dogs = new List<Dog>()
            {
                new Dog("Casper", false),
                new Dog("Sif", true),
                new Dog("Oreo", false),
                new Dog("Pixel", false)
            };

        }

        public IEnumerator<Dog> GetEnumerator() // for generic example
        {
            return dogs.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator() // for non-generic example
        {
            throw new NotImplementedException();
        }
    }
}
