﻿using VirtualOverrideDemo;

Dog dog = new Dog("Sif", 15);
Console.WriteLine($"{dog.Name} is {dog.Age} years old");
dog.MakeSound();
dog.Play();
dog.Eat();
