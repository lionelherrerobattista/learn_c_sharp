﻿// Method 1
string[] lines = { "first line", "second line", "third line" };
File.WriteAllLines(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\textFile2.txt", lines);

string[] lines2 = { "User 1: 1010", "User 2: 5010", "User 1: 2210" };
File.WriteAllLines(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\highScores.txt", lines2);

// Method 2
//Console.WriteLine("Please give the file a name");
//string fileName = Console.ReadLine();
//Console.WriteLine("Please enter the text for the file");
//string input = Console.ReadLine();

//File.WriteAllText(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\" + fileName + ".txt", input);

// Method 3
using (StreamWriter file = new StreamWriter(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\myText2.txt"))
{
    foreach(string line in lines2)
    {
        if (line.Contains("2")) // example check for content
        {
            file.WriteLine(line);
        }
    }
}

using (StreamWriter file = new StreamWriter(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\"
    + @"Assets\myText2.txt", true))
{
    file.WriteLine("Additional line");
}



/*
string text = System.IO.File.ReadAllText(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\textFile.txt");

Console.WriteLine($"Textfile contains the following text:\n{text}");

string[] lines = System.IO.File.ReadAllLines(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\textFile.txt");

Console.WriteLine("Contents of textFile.txt: ");
foreach (string line in lines)
    Console.WriteLine($"\t{line}");
*/