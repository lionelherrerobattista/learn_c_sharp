﻿using System.Collections;
/*
// arrayList
// declaring an ArrayList
ArrayList myArrayList = new ArrayList(); // undefined amount
ArrayList myArrayList2 = new ArrayList(100); // defined

// add elements
myArrayList.Add(25);
myArrayList.Add("Hello");
myArrayList.Add(13.37);
myArrayList.Add(13);
myArrayList.Add(128);
myArrayList.Add(25.3);
myArrayList.Add(13);

// delete specific element (first instance)
myArrayList.Remove(13); 

// delete at specific index
myArrayList.RemoveAt(0);

// how many objects
Console.WriteLine(myArrayList.Count);

double sum = 0;

foreach (object obj in myArrayList)
{
    if(obj is int)
    {
        sum += Convert.ToDouble(obj);
    } 
    else if (obj is double)
    {
        sum += (double) obj;
    }
    else if(obj is string)
    {
        Console.WriteLine(obj);
    }
}

Console.WriteLine(sum);

// Lists
// declaration
var numbers = new List<int> { 1, 5, 35, 100 }; // List with values
var numbers2 = new List<int>(); // List without values

// adding and removing values
numbers.Add(7);
numbers.Remove(7);

int index = 0;
numbers.RemoveAt(index);

// getting a value
int value = numbers[0];
Console.WriteLine(value); // 5

numbers.Clear();
Console.WriteLine(numbers.Count); // 0
*/

List<int> intList = new List<int>();

for (int i = 100; i <= 170; i++)
{
    if(i % 2 == 0)
        intList.Add(i);
}

foreach (var number in intList)
    Console.WriteLine(number);