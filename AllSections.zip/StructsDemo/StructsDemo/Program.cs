﻿using StructsDemo;

Game game1;

game1.name = "Pokemon Go";
game1.developer = "Niantic";
game1.rating = 3.5;
game1.releaseDate = "01.07.2016";

game1.Display();