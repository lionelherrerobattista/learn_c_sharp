﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructsDemo
{
    struct Game
    {
        public string name;
        public string developer;
        public double rating;
        public string releaseDate;

        public void Display()
        {

            Console.WriteLine($"Game 1's name is: {name}");
            Console.WriteLine($"Game 1's was developed by: {developer}");
            Console.WriteLine($"Game 1's rating is: {rating}");
            Console.WriteLine($"Game 1's was released in: {releaseDate}");
        }
    }

    internal class Helper
    {
    }
}
