﻿using AbstractClassesDemo;

Shape[] shapes = { new Sphere(4), new Cube(3) };

foreach (var shape in shapes)
{
    shape.GetInfo();
    Console.WriteLine($"{shape.Name} has a volume of {shape.CalculateVolume()}");

    // check type
    Cube iceCube = shape as Cube;
    if(iceCube == null ) // is not a cube
    {
        Console.WriteLine("This shape is no cube");
    }

    if(shape is Cube)
    {
        Console.WriteLine("This shape is a cube");
    }

    object cube1 = new Cube(7);
    Cube cube2 = (Cube) cube1;
}