﻿using IEnumerableDemo;
/*
IEnumerable<int> unknownCollection;
unknownCollection = Helper.GetCollection(1);

Console.WriteLine("This was a List<int>");

foreach (int num in unknownCollection)
{
    Console.Write(num + " ");
}

unknownCollection = Helper.GetCollection(2);

Console.WriteLine("");
Console.WriteLine("This was a Queue<int>");

foreach (int num in unknownCollection)
{
    Console.Write(num + " ");
}

unknownCollection = Helper.GetCollection(3);

Console.WriteLine("");
Console.WriteLine("This was an Array of int");

foreach (int num in unknownCollection)
{
    Console.Write(num + " ");
}
*/

List<int> numberList = new List<int>() { 8, 6, 2 };
int[] numberArray = new int[] { 1, 7, 1, 3 };

Console.WriteLine(" ");

Helper.CollectionSum(numberList);

Console.WriteLine(" ");

Helper.CollectionSum(numberArray);