﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    internal class Audi : Car
    {
        public string Model { get; set; }
        private string Brand { get; set; }

        public Audi(int hp, string color, string model)
            : base(hp, color)
        {
            Model = model;
            Brand = "Audi";
        }

        public void ShowDetails()
        {
            Console.WriteLine($"HP: {HP} Color: {Color}" +
                $" Brand: {Brand} Model: {Model}");
        }

        public override void Repair()
        {
            Console.WriteLine($"{Brand} {Model} was repaired!");
        }
    }
}
