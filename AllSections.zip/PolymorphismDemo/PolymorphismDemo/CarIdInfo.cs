﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    // Has a

    internal class CarIdInfo
    {
        public int IdNum { get; set; } = 0;
        public string Owner { get; set; } = "No owner";
    }
}
