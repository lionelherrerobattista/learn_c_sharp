﻿//Console.WriteLine("1");
//Thread.Sleep(1000);
//Console.WriteLine("2");
//Thread.Sleep(1000);
//Console.WriteLine("3");
//Thread.Sleep(1000);
//Console.WriteLine("4");
/*
new Thread(() =>
{
    Thread.Sleep(1000);
    Console.WriteLine("Thread 1");

}).Start();
new Thread(() =>
{
    Thread.Sleep(1000);
    Console.WriteLine("Thread 2");

}).Start();
new Thread(() =>
{
    Thread.Sleep(1000);
    Console.WriteLine("Thread 3");

}).Start();
new Thread(() =>
{
    Thread.Sleep(1000);
    Console.WriteLine("Thread 4");

}).Start();



// thread start, end and completion

var taskCompletionSource  = new TaskCompletionSource<bool>();

var thread = new Thread(() =>
{

    Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} started");
    Thread.Sleep(5000);
    taskCompletionSource.TrySetResult(true);
    Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} ended");
});

thread.Start();
var test = taskCompletionSource.Task.Result;
Console.WriteLine($"Task was done: {test}");



//Thread pools
new Thread(() =>
{

    Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} started");
    Thread.Sleep(5000);
    Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} ended");
})
{ IsBackground = true }.Start();

Enumerable.Range(0, 100).ToList().ForEach(x =>
{
    ThreadPool.QueueUserWorkItem((obj) =>
    {
        Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} started");

        Thread.Sleep(1000);

        Console.WriteLine($"Thread number: {Thread.CurrentThread.ManagedThreadId} ended");
    });

});

Console.ReadLine();
*/


using ThreadsDemo;

Console.WriteLine("Main thread sarted");

Thread threadOne = new Thread(Helper.ThreadOneFunction);
Thread threadTwo = new Thread(Helper.ThreadTwoFunction);

threadOne.Start();
threadTwo.Start();

//threadOne.Join();
//Console.WriteLine("ThreadOneFunction done");
//threadTwo.Join();
//Console.WriteLine("ThreadTwoFunction done");

if(threadOne.Join(1000))
{
    Console.WriteLine("ThreadOneFunction done");
}
else
{
    Console.WriteLine("ThreadOneFunction wasn't done within 1 sec");
}
for (int i = 0; i < 10; i++)
{
    if (threadOne.IsAlive)
    {
        Console.WriteLine("ThreadOne is still doing stuff");
        Thread.Sleep(300);
    }
    else
    {
        Console.WriteLine("ThreadOne completed.");
    }
}

Console.WriteLine("Main thread ended");