﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsDemo
{
    internal class Helper
    {
        public static void ThreadOneFunction()
        {
            Console.WriteLine("ThreadOneFunctionStarted");
            Thread.Sleep(3000);
            Console.WriteLine("ThreadOneFunction coming back to caller");
        }
        public static void ThreadTwoFunction()
        {
            Console.WriteLine("ThreadTwoFunctionStarted");
        }
    }
}
