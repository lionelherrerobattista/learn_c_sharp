﻿using System.Text.RegularExpressions;

using (StreamReader sr = new StreamReader(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\input.txt"))
{
    string line;
    string split;

    while((line = sr.ReadLine()) != null)
    {
        if(line.Contains("split"))
        {
            split = line.Split()[4];
            using(StreamWriter file = new StreamWriter(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\output.txt", true))
            {
                file.Write(split + " ");
            }
        }
    }
}

using(StreamReader sr = new StreamReader(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\input2.txt"))
{
    string text = sr.ReadToEnd();
    string pattern = @"\d{2,3}";

    Regex regex = new Regex(pattern);

    MatchCollection matches = regex.Matches(text);

    foreach (Match match in matches)
    {
        GroupCollection group = match.Groups;

        int value = int.Parse(group[0].Value);

        using (StreamWriter file = new StreamWriter(@"C:\Users\lion_\Desktop\workspace\learn_c_sharp\Assets\output.txt", true))
        {
            file.Write((char)value);
        }
    }

}

