﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo1
{
    internal class Helper
    {

        public static void OddNumbers(int[] numbers)
        {
            Console.WriteLine("Odd Numbers:");

            IEnumerable<int> oddNumbers =
                from number in numbers
                where number % 2 != 0
                select number;

            Console.WriteLine(oddNumbers);

            foreach (int number in oddNumbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
