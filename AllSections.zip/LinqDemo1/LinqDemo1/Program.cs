﻿using LinqDemo1;

int[] numbers = new int[9];

for (int i = 0; i < 9; i++)
{
    numbers[i] = i + 1;
}

Helper.OddNumbers(numbers);
